package com.venu.ai;
import android.app.*; import android.os.*; import android.content.*; import android.provider.Settings; import android.widget.*;
public class MainActivity extends Activity {
 EditText command; TextView status;
 public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
  command=findViewById(R.id.command); status=findViewById(R.id.status);
  findViewById(R.id.run).setOnClickListener(v->{ String c=command.getText().toString().trim(); if(c.isEmpty()){status.setText("Enter a task."); return;} status.setText("Task received:\n\n"+c+"\n\nAI backend integration is not enabled in this starter build. No remote code is executed automatically."); });
  findViewById(R.id.accessibility).setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
 }
}
