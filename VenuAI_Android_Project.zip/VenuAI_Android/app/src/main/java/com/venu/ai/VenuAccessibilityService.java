package com.venu.ai;
import android.accessibilityservice.AccessibilityService; import android.view.accessibility.AccessibilityEvent;
public class VenuAccessibilityService extends AccessibilityService {
 public void onAccessibilityEvent(AccessibilityEvent e) {}
 public void onInterrupt() {}
}
